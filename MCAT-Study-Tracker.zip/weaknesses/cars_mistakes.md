# CARS Mistakes Log

| Passage | Question | Error Type | Notes |
|---------|----------|------------|-------|
| 6       | 3        | Inference  | Misread author's tone |
# 📅 Daily Log – YYYY-MM-DD

## ✅ What I Studied Today:
- [ ] Topic 1
- [ ] Topic 2

## 🧠 Key Takeaways:
- Insight 1
- Insight 2

## ❌ Mistakes or Struggles:
- Mistake 1

## 🔁 24/7/W Review Log:
| Topic | 24hr Review Done? | 7d Review Scheduled? | Weekend Review? |
|-------|-------------------|----------------------|------------------|
| Example Topic | ⬜ | ⬜ | ⬜ |

## 🎯 Tomorrow’s Plan:
- [ ] Plan 1

## 💬 Reflection:
> Freeform journaling here
# 24/7/W Review Guide

Use this protocol to retain high-yield MCAT topics.

- 24hr after studying → 1st review
- 7 days later → 2nd review
- Weekly (weekend) → Final reinforcement

Track in your daily log or review log file.
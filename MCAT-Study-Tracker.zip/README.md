# MCAT Study Tracker

This is your personal MCAT prep system using GitHub to organize logs, reviews, weaknesses, and reflections.

## Folder Structure
- `logs/`: Daily logs
- `review/`: 24/7/W review tracking
- `tools/`: Scripts and guides
- `practice/`: Score and question tracking
- `weaknesses/`: Mistake journaling by section
